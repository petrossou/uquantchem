 perl -pe 's/([\d\.-]+)/$1 < 1 ? $1 + 0 : $1/ge' ANO-RCC-VDZ.raw  >> New

